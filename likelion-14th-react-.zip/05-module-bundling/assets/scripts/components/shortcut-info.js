import React from 'react';
export default function ShortcutInfo() {
  return /*#__PURE__*/React.createElement("p", {
    className: "shortcut-info"
  }, /*#__PURE__*/React.createElement("code", null, "Shift+Enter"), " \uD0A4\uB97C \uB204\uB974\uBA74 \uC560\uB2C8\uBA54\uC774\uC158\uC774 \uB2E4\uC2DC \uC2DC\uC791\uB429\uB2C8\uB2E4.");
}