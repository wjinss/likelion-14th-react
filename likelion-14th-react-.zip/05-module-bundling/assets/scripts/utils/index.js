export { default as getRandomMinMax } from './get-random-min-max.js';
export { default as getRandomHue } from './get-random-hue.js';
export { default as setDocumentTitle } from './set-document-title.js';
export { default as setAppRandomHue } from './set-app-random-hue.js';
export { default as setCurrency } from './set-currency.js';