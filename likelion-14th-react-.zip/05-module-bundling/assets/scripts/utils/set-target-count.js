import getRandomMinMax from './get-random-min-max.js';
export default function setTargetCount() {
  targetCount = getRandomMinMax();
}