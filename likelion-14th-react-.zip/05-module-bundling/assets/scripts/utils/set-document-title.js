export default function setDocumentTitle(originTitle, targetCount) {
  document.title = originTitle + ` (${targetCount})`;
}