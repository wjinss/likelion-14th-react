export default function setCurrency(price) {
  return price.toLocaleString()
}
