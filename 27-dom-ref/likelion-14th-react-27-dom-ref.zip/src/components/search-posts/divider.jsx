export default function Divider() {
  return (
    <hr className="mt-6 mb-8 border-0 border-b-[0.1px] border-indigo-800" />
  )
}
