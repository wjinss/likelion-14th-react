export default function Shortcut() {
  return (
    <p className="shortcut-info">
      <code>Shift + Enter</code> 키를 누르면 애니메이션이 다시 시작됩니다.
    </p>
  )
}
